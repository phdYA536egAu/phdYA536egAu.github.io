/** Automatically generated file. DO NOT MODIFY */
package com.jakewp11.template;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}